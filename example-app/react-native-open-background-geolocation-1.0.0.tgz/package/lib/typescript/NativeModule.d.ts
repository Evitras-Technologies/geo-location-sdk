import { NativeEventEmitter } from 'react-native';
/**
 * Raw native module. Every method returns a Promise resolved/rejected by the
 * platform implementation. Return payloads are untyped maps at this boundary;
 * the JS facade in `BackgroundGeolocation.ts` narrows them to the public
 * domain types — do not call this module directly from application code.
 */
export interface NativeBackgroundGeolocation {
    ready(config: Record<string, unknown>): Promise<any>;
    setConfig(config: Record<string, unknown>): Promise<any>;
    reset(config: Record<string, unknown>): Promise<any>;
    getState(): Promise<any>;
    start(): Promise<any>;
    stop(): Promise<any>;
    startGeofences(): Promise<any>;
    changePace(isMoving: boolean): Promise<void>;
    getCurrentPosition(options: Record<string, unknown>): Promise<any>;
    watchPosition(options: Record<string, unknown>): Promise<void>;
    stopWatchPosition(): Promise<void>;
    getOdometer(): Promise<number>;
    setOdometer(value: number): Promise<any>;
    getLocations(): Promise<any[]>;
    getCount(): Promise<number>;
    insertLocation(location: Record<string, unknown>): Promise<string>;
    destroyLocations(): Promise<void>;
    destroyLocation(uuid: string): Promise<void>;
    sync(): Promise<any[]>;
    addGeofence(geofence: Record<string, unknown>): Promise<void>;
    addGeofences(geofences: Array<Record<string, unknown>>): Promise<void>;
    removeGeofence(identifier: string): Promise<void>;
    removeGeofences(): Promise<void>;
    getGeofences(): Promise<any[]>;
    getGeofence(identifier: string): Promise<any>;
    geofenceExists(identifier: string): Promise<boolean>;
    requestPermission(): Promise<number>;
    requestLocationServices(): Promise<boolean>;
    requestAllPermissions(): Promise<any>;
    getPermissionStatus(): Promise<any>;
    requestTemporaryFullAccuracy(purpose: string): Promise<number>;
    getProviderState(): Promise<any>;
    isPowerSaveMode(): Promise<boolean>;
    getSensors(): Promise<any>;
    getDeviceInfo(): Promise<any>;
    getDeviceId(): Promise<string>;
    startBackgroundTask(): Promise<number>;
    stopBackgroundTask(taskId: number): Promise<void>;
    playSound(soundId: number): Promise<void>;
    getLog(): Promise<string>;
    destroyLog(): Promise<void>;
    emailLog(email: string): Promise<void>;
    log(level: string, message: string): Promise<void>;
    showSettings(setting: string): Promise<void>;
    isIgnoringBatteryOptimizations(): Promise<boolean>;
    addListener(eventName: string): void;
    removeListeners(count: number): void;
}
export declare const NativeModule: NativeBackgroundGeolocation;
export declare const EventEmitter: NativeEventEmitter;
/** Native event names emitted over the RCTEventEmitter / DeviceEventEmitter bridge. */
export declare const NativeEvents: {
    readonly LOCATION: "location";
    readonly MOTIONCHANGE: "motionchange";
    readonly ACTIVITYCHANGE: "activitychange";
    readonly PROVIDERCHANGE: "providerchange";
    readonly GEOFENCE: "geofence";
    readonly GEOFENCESCHANGE: "geofenceschange";
    readonly HEARTBEAT: "heartbeat";
    readonly HTTP: "http";
    readonly CONNECTIVITYCHANGE: "connectivitychange";
    readonly POWERSAVECHANGE: "powersavechange";
    readonly ENABLEDCHANGE: "enabledchange";
    readonly NOTIFICATIONACTION: "notificationaction";
    readonly WATCHPOSITION: "watchposition";
};
//# sourceMappingURL=NativeModule.d.ts.map