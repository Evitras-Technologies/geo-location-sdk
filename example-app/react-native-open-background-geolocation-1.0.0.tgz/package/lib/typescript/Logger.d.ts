/**
 * The SDK's persistent logger. Log entries are stored in the SDK database
 * (pruned after `Config.logMaxDays`) and can be fetched or emailed for
 * field debugging.
 *
 * ```ts
 * import BackgroundGeolocation, { Logger } from 'react-native-open-background-geolocation';
 *
 * Logger.info('Something interesting happened');
 * const log = await Logger.getLog();
 * ```
 */
export declare const Logger: {
    error(message: string): Promise<void>;
    warn(message: string): Promise<void>;
    info(message: string): Promise<void>;
    debug(message: string): Promise<void>;
    notice(message: string): Promise<void>;
    /** The entire persisted log as a single string, newest entries last. */
    getLog(): Promise<string>;
    /** Delete all persisted log entries. */
    destroyLog(): Promise<void>;
    /** Open the platform mail composer with the log attached/inlined. */
    emailLog(email: string): Promise<void>;
};
//# sourceMappingURL=Logger.d.ts.map