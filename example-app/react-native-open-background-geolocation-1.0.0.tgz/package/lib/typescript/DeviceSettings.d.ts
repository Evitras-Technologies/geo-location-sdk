/**
 * Helpers for redirecting the user to vendor-specific device settings which
 * affect background tracking reliability (battery optimization whitelisting,
 * OEM "auto-start" managers, …). Android only; no-ops on iOS.
 *
 * ```ts
 * import { DeviceSettings } from 'react-native-open-background-geolocation';
 *
 * await DeviceSettings.showIgnoreBatteryOptimizations();
 * ```
 */
export declare const DeviceSettings: {
    /**
     * Show the direct system "Allow app to run in background?" dialog which
     * whitelists your app from battery optimization — the single most important
     * step for reliable tracking on Xiaomi / Vivo / Oppo / Realme / Samsung
     * devices. Resolves immediately when already whitelisted.
     */
    showIgnoreBatteryOptimizations(): Promise<void>;
    /** `true` when the app is already whitelisted from battery optimization (always `true` on iOS). */
    isIgnoringBatteryOptimizations(): Promise<boolean>;
    /** Open the OEM power-manager / auto-start screen when the vendor exposes one (Huawei, Xiaomi, Oppo, …). */
    showPowerManager(): Promise<void>;
    /** Open your app's system settings page. */
    show(): Promise<void>;
};
//# sourceMappingURL=DeviceSettings.d.ts.map