import type { Subscription } from './types/Config';
interface ScheduleWindow {
    /** Days of week the window applies to; 1 = Sunday … 7 = Saturday. */
    days: number[];
    /** Window start, minutes after midnight. */
    startMinutes: number;
    /** Window end, minutes after midnight. */
    endMinutes: number;
}
/**
 * Evaluates {@link Config.schedule} entries of the form `"{DAYS} {START}-{END}"`
 * (e.g. `"2-6 09:00-17:00"`, `"1,7 10:00-14:00"`) once per minute while the
 * JS runtime is alive, starting/stopping tracking as windows open and close.
 *
 * Note: unlike native alarm scheduling, this runs in the JS thread — windows
 * are honored while your app is running (foreground or background-headless).
 */
export declare class Scheduler {
    private readonly engageTracking;
    private readonly disengageTracking;
    private windows;
    private timer;
    private trackingEngaged;
    private listeners;
    constructor(engageTracking: () => Promise<unknown>, disengageTracking: () => Promise<unknown>);
    start(schedule: string[], currentlyEnabled: boolean): void;
    stop(): void;
    get isRunning(): boolean;
    onSchedule(listener: () => void): Subscription;
    private evaluate;
    private notify;
    /** Parse `"2-6 09:00-17:00"` / `"1,3,5 08:30-12:00"`; returns `null` on malformed input. */
    static parse(entry: string): ScheduleWindow | null;
}
export {};
//# sourceMappingURL=Scheduler.d.ts.map